# 🚀 Centralized Logging with Grafana Loki - Complete Guide

## 📖 Table of Contents

1. [Introduction](#introduction)
2. [Understanding Centralized Logging](#understanding-centralized-logging)
3. [What is Grafana Loki?](#what-is-grafana-loki)
4. [Loki Architecture](#loki-architecture)
5. [Installing Loki on VM (Docker/Docker Compose)](#installing-loki-on-vm-dockerdocker-compose)
6. [Installing Loki on Kubernetes](#installing-loki-on-kubernetes)
7. [Configuring Loki](#configuring-loki)
8. [Visualizing Logs with Grafana](#visualizing-logs-with-grafana)
9. [LogQL - Query Language](#logql---query-language)
10. [Real-World Examples](#real-world-examples)
11. [Best Practices](#best-practices)
12. [Troubleshooting](#troubleshooting)

---

## Introduction

Welcome to the complete guide on Centralized Logging with Grafana Loki! This guide is designed for everyone - from complete beginners to those looking to deepen their DevOps knowledge. We'll build your understanding step by step, using real-world analogies and working examples.

### What You'll Learn

- ✅ What centralized logging is and why it matters
- ✅ How Loki works under the hood
- ✅ How to install and configure Loki on VMs and Kubernetes
- ✅ How to query logs with LogQL
- ✅ How to visualize logs in Grafana
- ✅ Best practices and troubleshooting tips

---

## Understanding Centralized Logging

### 📚 The Library Analogy

Imagine you're running a large library with hundreds of thousands of books (your application logs). Without a proper system:

- Books are scattered everywhere
- Finding a specific book takes hours
- You can't track who borrowed what
- Different sections use different organization systems

**Centralized Logging** is like building a modern library management system where:

- All books (logs) are cataloged in one place
- You can search for any book instantly
- Everything is organized with tags (labels)
- You can track patterns and trends

### Why Do We Need Centralized Logging?

#### The Problem Without Centralized Logging

```mermaid
graph TB
    A[Microservice 1] -->|Logs to local file| B[Server 1 /var/log]
    C[Microservice 2] -->|Logs to local file| D[Server 2 /var/log]
    E[Microservice 3] -->|Logs to local file| F[Server 3 /var/log]
    G[Microservice 4] -->|Logs to local file| H[Server 4 /var/log]
    
    I[😰 Developer] -.->|SSH to each server| B
    I -.->|SSH to each server| D
    I -.->|SSH to each server| F
    I -.->|SSH to each server| H
    
    style I fill:#ff6b6b
```

**Problems:**

- 🔴 Have to SSH into multiple servers
- 🔴 Can't correlate logs across services
- 🔴 Time-consuming troubleshooting
- 🔴 No central search capability
- 🔴 Logs get lost when servers die

#### The Solution With Centralized Logging

```mermaid
graph TB
    A[Microservice 1] -->|Sends logs| E[Loki]
    B[Microservice 2] -->|Sends logs| E
    C[Microservice 3] -->|Sends logs| E
    D[Microservice 4] -->|Sends logs| E
    
    E --> F[Grafana Dashboard]
    G[😊 Developer] -->|Single interface| F
    
    style G fill:#51cf66
    style E fill:#4dabf7
    style F fill:#ffd43b
```

**Benefits:**

- ✅ All logs in one place
- ✅ Search across all services instantly
- ✅ Correlate events across the system
- ✅ Create alerts and dashboards
- ✅ Logs are safe even if servers crash

---

## What is Grafana Loki?

### 🎯 The Simple Explanation

**Loki** is like a super-efficient librarian for your logs. Instead of reading every page of every book (log), it only indexes the book titles and metadata (labels), making searches incredibly fast and cheap.

### Key Concepts

#### 1. **Labels vs Full-Text Indexing**

Think of labels like the Dewey Decimal System in a library:

**Traditional Logging (e.g., Elasticsearch):**

- Indexes every word in every log (like memorizing every word in every book)
- Very powerful but expensive in storage and memory
- Like having a photographic memory of every page

**Loki's Approach:**

- Only indexes metadata/labels (like book title, author, category)
- Stores log content in highly compressed chunks
- Much cheaper and faster
- Like organizing books by subject without reading every page

```mermaid
graph LR
    A[Log Entry] --> B{Loki Processing}
    B -->|Extracts| C[Labels<br/>service=api<br/>level=error<br/>host=server1]
    B -->|Compresses| D[Log Content<br/>Stored in Chunks]
    
    C --> E[Small Index<br/>Fast Search]
    D --> F[Compressed Storage<br/>Low Cost]
    
    style E fill:#51cf66
    style F fill:#51cf66
```

#### 2. **Log Streams**

A **log stream** is a set of logs that share the same labels. Think of it as books in the same category.

Example:

```
Stream 1: {service="api", env="production", host="server1"}
Stream 2: {service="api", env="production", host="server2"}
Stream 3: {service="database", env="production", host="server3"}
```

#### 3. **Chunks**

Logs are compressed and stored in **chunks** - like zip files of related log entries. This makes storage incredibly efficient.

### Loki vs Traditional Log Systems

| Feature | Traditional (e.g., Elasticsearch) | Loki |
|---------|----------------------------------|------|
| **Indexing** | Full-text index on all log content | Only labels/metadata |
| **Storage Cost** | High (needs lots of memory/disk) | Low (highly compressed) |
| **Query Speed** | Very fast for complex text searches | Fast for label-based queries |
| **Best For** | Complex text analysis | Metrics-style log aggregation |
| **RAM Required** | High (GBs per node) | Low (MBs per node) |
| **Scalability** | Harder to scale | Easy horizontal scaling |

---

## Loki Architecture

### 📊 High-Level Overview

```mermaid
graph TB
    subgraph "Data Collection"
        A1[Application Logs]
        A2[System Logs]
        A3[Container Logs]
        
        A1 --> B[Alloy/Promtail<br/>Log Agent]
        A2 --> B
        A3 --> B
    end
    
    subgraph "Loki Server"
        B -->|HTTP POST| C[Distributor<br/>Load Balancer]
        C --> D[Ingester<br/>Writes & Buffers]
        D --> E[Storage<br/>Object Store<br/>S3/GCS/Minio]
        
        F[Query Frontend<br/>Query Optimizer] --> G[Querier<br/>Executes Queries]
        G --> E
        G --> D
    end
    
    subgraph "Visualization"
        H[Grafana] -->|LogQL Queries| F
        I[User] --> H
    end
    
    style C fill:#ff6b6b
    style D fill:#ffd43b
    style G fill:#51cf66
    style H fill:#4dabf7
```

### 🔍 Understanding Each Component

#### 1. **Log Agent (Alloy/Promtail)**

**What it does:** Collects logs from your applications and sends them to Loki

**Analogy:** Like a mail carrier picking up letters (logs) from mailboxes (applications) and delivering them to the post office (Loki).

**Key Features:**

- Discovers log sources automatically
- Adds labels to logs
- Handles retries if Loki is temporarily down
- Supports multiple log formats

**Note:** Promtail is being deprecated in favor of Grafana Alloy (the new unified agent).

#### 2. **Distributor**

**What it does:** Receives logs from agents and distributes them to ingesters

**Analogy:** Like a sorting facility in a post office that determines which warehouse should store which package.

**Key Responsibilities:**

- Validates incoming logs
- Checks rate limits per tenant
- Uses consistent hashing to route logs to ingesters
- Ensures high availability through replication

```mermaid
graph LR
    A[Alloy] -->|Sends Logs| B[Distributor]
    B -->|Hash & Route| C[Ingester 1]
    B -->|Hash & Route| D[Ingester 2]
    B -->|Hash & Route| E[Ingester 3]
    
    style B fill:#ff6b6b
```

#### 3. **Ingester**

**What it does:** Receives logs, builds chunks, and flushes them to storage

**Analogy:** Like a warehouse worker who receives items, organizes them into boxes, and stores them on shelves.

**Key Responsibilities:**

- Keeps recent logs in memory for fast queries
- Compresses logs into chunks
- Periodically flushes chunks to object storage
- Maintains indexes for fast retrieval

**Lifecycle:**

```mermaid
sequenceDiagram
    participant D as Distributor
    participant I as Ingester
    participant S as Storage
    
    D->>I: Send log stream
    Note over I: Accumulate logs<br/>in memory
    Note over I: Compress into<br/>chunk (10MB)
    I->>S: Flush chunk
    Note over S: Store in<br/>object storage
```

#### 4. **Storage**

**What it does:** Long-term storage for log chunks and indexes

**Supported Options:**

- **Local Filesystem** (development only)
- **Amazon S3**
- **Google Cloud Storage (GCS)**
- **Azure Blob Storage**
- **MinIO** (S3-compatible)

**Storage Structure:**

```
Storage
├── Chunks (compressed log content)
│   ├── chunk-abc123.gz
│   ├── chunk-def456.gz
│   └── chunk-ghi789.gz
└── Index (labels and references)
    ├── index-2025-10-30.tsdb
    └── index-2025-10-31.tsdb
```

#### 5. **Query Frontend & Querier**

**What they do:** Process LogQL queries and retrieve logs

**Analogy:**

- **Query Frontend:** Like a librarian who helps you refine your search
- **Querier:** Like an assistant who fetches the actual books

**Query Flow:**

```mermaid
sequenceDiagram
    participant G as Grafana
    participant QF as Query Frontend
    participant Q as Querier
    participant I as Ingester
    participant S as Storage
    
    G->>QF: LogQL Query
    Note over QF: Split & Optimize<br/>Query
    QF->>Q: Distribute subqueries
    Q->>I: Query recent logs
    Q->>S: Query historical logs
    I->>Q: Return results
    S->>Q: Return results
    Q->>QF: Merge results
    QF->>G: Final results
```

#### 6. **Compactor**

**What it does:** Optimizes stored data

**Key Tasks:**

- Merges small chunks into larger ones
- Removes duplicate data
- Applies retention policies
- Rebuilds indexes for better performance

### 📈 Data Flow Diagram

```mermaid
flowchart TB
    subgraph "1. Collection"
        A[Your App] -->|Writes logs| B[Log File/Stdout]
        B --> C[Alloy Agent]
    end
    
    subgraph "2. Processing"
        C -->|HTTP Push| D[Distributor]
        D -->|Distribute| E[Ingester]
        E -->|Buffer & Compress| F[Chunks in Memory]
    end
    
    subgraph "3. Storage"
        F -->|Flush periodically| G[Object Storage<br/>S3/GCS/MinIO]
    end
    
    subgraph "4. Querying"
        H[User] -->|Write LogQL| I[Grafana]
        I -->|Query| J[Query Frontend]
        J -->|Optimize| K[Querier]
        K -->|Read recent| E
        K -->|Read historical| G
    end
    
    K -->|Results| I
    I -->|Visualize| H
    
    style A fill:#e9ecef
    style D fill:#ff6b6b
    style E fill:#ffd43b
    style K fill:#51cf66
    style I fill:#4dabf7
```

---

## Installing Loki on VM (Docker/Docker Compose)

### 🐳 Quick Start with Docker Compose

This section will get you up and running with a complete logging stack in under 5 minutes!

#### Prerequisites

- Docker installed (version 20.10+)
- Docker Compose installed (version 2.0+)
- At least 2GB of free RAM
- Port 3000 (Grafana) and 3100 (Loki) available

### Option 1: Simple Single-Node Setup

This is perfect for:

- Learning and testing
- Small applications
- Development environments
- Personal projects

#### Step 1: Create Project Directory

```bash
# Create a directory for our Loki stack
mkdir loki-stack
cd loki-stack
```

#### Step 2: Create Loki Configuration

Create a file called `loki-config.yaml`:

```bash
cat > loki-config.yaml << 'EOF'
---
server:
  http_listen_address: 0.0.0.0
  http_listen_port: 3100

memberlist:
  join_members: ["read", "write", "backend"]
  dead_node_reclaim_time: 30s
  gossip_to_dead_nodes_time: 15s
  left_ingesters_timeout: 30s
  bind_addr: ['0.0.0.0']
  bind_port: 7946
  gossip_interval: 2s

schema_config:
  configs:
    - from: 2023-01-01
      store: tsdb
      object_store: s3
      schema: v13
      index:
        prefix: index_
        period: 24h
common:
  path_prefix: /loki
  replication_factor: 1
  compactor_address: http://backend:3100
  storage:
    s3:
      endpoint: minio:9000
      insecure: true
      bucketnames: loki-data
      access_key_id: loki
      secret_access_key: supersecret
      s3forcepathstyle: true
  ring:
    kvstore:
      store: memberlist
ruler:
  storage:
    s3:
      bucketnames: loki-ruler

compactor:
  working_directory: /tmp/compactor
EOF
```

**Configuration Explanation:**

| Setting | What it Does | Analogy |
|---------|-------------|---------|
| `auth_enabled: false` | Disables multi-tenancy | Like a library that doesn't require membership cards |
| `http_listen_port: 3100` | Port for receiving logs | The address where mail is delivered |
| `storage.filesystem` | Store data locally | Using your computer's hard drive instead of cloud storage |
| `replication_factor: 1` | No data replication | Keeping one copy of each book |
| `retention_period: 744h` | Keep logs for 31 days | Automatically discard logs older than 31 days |

#### Step 3: Create Alloy Configuration

Create a file called `alloy-local-config.yaml`:

```bash
cat > alloy-local-config.yaml << 'EOF'
logging {
  level  = "info"
  format = "logfmt"
}

// Scrape logs from a file
local.file_match "logs" {
  path_targets = [{
    __path__ = "/var/log/*.log",
    job      = "varlogs",
  }]
}

loki.source.file "local_files" {
  targets    = local.file_match.logs.targets
  forward_to = [loki.write.local_loki.receiver]
}

// Send logs to Loki
loki.write "local_loki" {
  endpoint {
    url = "http://loki:3100/loki/api/v1/push"
  }
}

// Scrape logs from Docker containers
discovery.docker "containers" {
  host = "unix:///var/run/docker.sock"
}

loki.source.docker "docker_logs" {
  host       = "unix:///var/run/docker.sock"
  targets    = discovery.docker.containers.targets
  forward_to = [loki.write.local_loki.receiver]
  relabel_rules = loki.relabel.docker.rules
}

loki.relabel "docker" {
  rule {
    source_labels = ["__meta_docker_container_name"]
    target_label  = "container"
  }
  rule {
    source_labels = ["__meta_docker_container_log_stream"]
    target_label  = "stream"
  }
}
EOF
```

#### Step 4: Create Docker Compose File

Create `docker-compose.yaml`:

```bash
cat > docker-compose.yaml << 'EOF'
---
networks:
  loki:

services:
  read:
    image: grafana/loki:latest
    command: "-config.file=/etc/loki/config.yaml -target=read"
    ports:
      - 3101:3100
      - 7946
      - 9095
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    depends_on:
      - minio
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3100/ready || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    networks: &loki-dns
      loki:
        aliases:
          - loki

  write:
    image: grafana/loki:latest
    command: "-config.file=/etc/loki/config.yaml -target=write"
    ports:
      - 3102:3100
      - 7946
      - 9095
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3100/ready || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    depends_on:
      - minio
    networks:
      <<: *loki-dns

  alloy:
    image: grafana/alloy:latest
    volumes:
      - ./alloy-local-config.yaml:/etc/alloy/config.alloy:ro
      - /var/run/docker.sock:/var/run/docker.sock
      - /var/log:/var/log:ro
      
    command:  run --server.http.listen-addr=0.0.0.0:12345 --storage.path=/var/lib/alloy/data /etc/alloy/config.alloy
    ports:
      - 12345:12345
    depends_on:
      - gateway
    networks:
      - loki

  minio:
    image: minio/minio
    entrypoint:
      - sh
      - -euc
      - |
        mkdir -p /data/loki-data && \
        mkdir -p /data/loki-ruler && \
        minio server /data
    environment:
      - MINIO_ROOT_USER=loki
      - MINIO_ROOT_PASSWORD=supersecret
      - MINIO_PROMETHEUS_AUTH_TYPE=public
      - MINIO_UPDATE=off
    ports:
      - 9000
    volumes:
      - ./.data/minio:/data
    healthcheck:
      test: [ "CMD", "curl", "-f", "http://localhost:9000/minio/health/live" ]
      interval: 15s
      timeout: 20s
      retries: 5
    networks:
      - loki

  grafana:
    image: grafana/grafana:latest
    environment:
      - GF_PATHS_PROVISIONING=/etc/grafana/provisioning
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
    depends_on:
      - gateway
    entrypoint:
      - sh
      - -euc
      - |
        mkdir -p /etc/grafana/provisioning/datasources
        cat <<EOF > /etc/grafana/provisioning/datasources/ds.yaml
        apiVersion: 1
        datasources:
          - name: Loki
            type: loki
            access: proxy
            url: http://gateway:3100
            jsonData:
              httpHeaderName1: "X-Scope-OrgID"
            secureJsonData:
              httpHeaderValue1: "tenant1"
        EOF
        /run.sh
    ports:
      - "3000:3000"
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3000/api/health || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - loki

  backend:
    image: grafana/loki:latest
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    ports:
      - "3100"
      - "7946"
    command: "-config.file=/etc/loki/config.yaml -target=backend -legacy-read-mode=false"
    depends_on:
      - gateway
    networks:
      - loki
    

  gateway:
    image: nginx:latest
    depends_on:
      - read
      - write
    entrypoint:
      - sh
      - -euc
      - |
        cat <<EOF > /etc/nginx/nginx.conf
        user  nginx;
        worker_processes  5;  ## Default: 1

        events {
          worker_connections   1000;
        }

        http {
          resolver 127.0.0.11;

          server {
            listen             3100;

            location = / {
              return 200 'OK';
              auth_basic off;
            }

            location = /api/prom/push {
              proxy_pass       http://write:3100\$$request_uri;
            }

            location = /api/prom/tail {
              proxy_pass       http://read:3100\$$request_uri;
              proxy_set_header Upgrade \$$http_upgrade;
              proxy_set_header Connection "upgrade";
            }

            location ~ /api/prom/.* {
              proxy_pass       http://read:3100\$$request_uri;
            }

            location = /loki/api/v1/push {
              proxy_pass       http://write:3100\$$request_uri;
            }

            location = /loki/api/v1/tail {
              proxy_pass       http://read:3100\$$request_uri;
              proxy_set_header Upgrade \$$http_upgrade;
              proxy_set_header Connection "upgrade";
            }

            location ~ /loki/api/.* {
              proxy_pass       http://read:3100\$$request_uri;
            }
          }
        }
        EOF
        /docker-entrypoint.sh nginx -g "daemon off;"
    ports:
      - "3100:3100"
    healthcheck:
      test: ["CMD", "service", "nginx", "status"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - loki
  

  flog:
    image: mingrammer/flog
    command: -f json -d 200ms -l
    networks:
      - loki
EOF
```
<!-- 
#### Step 5: Create Grafana Datasource Configuration

Create `grafana-datasources.yaml`:

```bash
cat > grafana-datasources.yaml << 'EOF'
apiVersion: 1

datasources:
  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    isDefault: true
    version: 1
    editable: false
    jsonData:
      maxLines: 1000
EOF
``` -->

#### Step 5: Start the Stack

```bash
# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

**Expected Output:**

```
[+] Running 4/4
 ✔ Container loki     Started
 ✔ Container alloy    Started  
 ✔ Container grafana  Started
 ✔ Container flog     Started
```

#### Step 6: Verify Installation

```bash
# Check Loki is ready
curl http://localhost:3100/ready

# Check Loki metrics
curl http://localhost:3100/metrics

# Check services health
docker-compose ps
```

#### Step 7: Access Grafana

1. Open your browser and go to: `http://localhost:3000`
2. No login required (anonymous auth enabled)
3. Go to **Explore** (compass icon on the left)
4. You should see Loki as the default datasource
5. Try this query to see logs: `{job="varlogs"}`

### 🎯 Complete Working Example

Here's a complete example that includes a demo application generating logs:

Create `docker-compose-complete.yaml`:

```yaml
---
networks:
  loki:

services:
  read:
    image: grafana/loki:latest
    command: "-config.file=/etc/loki/config.yaml -target=read"
    ports:
      - 3101:3100
      - 7946
      - 9095
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    depends_on:
      - minio
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3100/ready || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    networks: &loki-dns
      loki:
        aliases:
          - loki

  write:
    image: grafana/loki:latest
    command: "-config.file=/etc/loki/config.yaml -target=write"
    ports:
      - 3102:3100
      - 7946
      - 9095
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3100/ready || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    depends_on:
      - minio
    networks:
      <<: *loki-dns

  alloy:
    image: grafana/alloy:latest
    volumes:
      - ./alloy-local-config.yaml:/etc/alloy/config.alloy:ro
      - /var/run/docker.sock:/var/run/docker.sock
      - /var/log:/var/log:ro
      
    command:  run --server.http.listen-addr=0.0.0.0:12345 --storage.path=/var/lib/alloy/data /etc/alloy/config.alloy
    ports:
      - 12345:12345
    depends_on:
      - gateway
    networks:
      - loki

  minio:
    image: minio/minio
    entrypoint:
      - sh
      - -euc
      - |
        mkdir -p /data/loki-data && \
        mkdir -p /data/loki-ruler && \
        minio server /data
    environment:
      - MINIO_ROOT_USER=loki
      - MINIO_ROOT_PASSWORD=supersecret
      - MINIO_PROMETHEUS_AUTH_TYPE=public
      - MINIO_UPDATE=off
    ports:
      - 9000
    volumes:
      - ./.data/minio:/data
    healthcheck:
      test: [ "CMD", "curl", "-f", "http://localhost:9000/minio/health/live" ]
      interval: 15s
      timeout: 20s
      retries: 5
    networks:
      - loki

  grafana:
    image: grafana/grafana:latest
    environment:
      - GF_PATHS_PROVISIONING=/etc/grafana/provisioning
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
    depends_on:
      - gateway
    entrypoint:
      - sh
      - -euc
      - |
        mkdir -p /etc/grafana/provisioning/datasources
        cat <<EOF > /etc/grafana/provisioning/datasources/ds.yaml
        apiVersion: 1
        datasources:
          - name: Loki
            type: loki
            access: proxy
            url: http://gateway:3100
            jsonData:
              httpHeaderName1: "X-Scope-OrgID"
            secureJsonData:
              httpHeaderValue1: "tenant1"
        EOF
        /run.sh
    ports:
      - "3000:3000"
    healthcheck:
      test: [ "CMD-SHELL", "wget --no-verbose --tries=1 --spider http://localhost:3000/api/health || exit 1" ]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - loki

  backend:
    image: grafana/loki:latest
    volumes:
      - ./loki-config.yaml:/etc/loki/config.yaml
    ports:
      - "3100"
      - "7946"
    command: "-config.file=/etc/loki/config.yaml -target=backend -legacy-read-mode=false"
    depends_on:
      - gateway
    networks:
      - loki
    

  gateway:
    image: nginx:latest
    depends_on:
      - read
      - write
    entrypoint:
      - sh
      - -euc
      - |
        cat <<EOF > /etc/nginx/nginx.conf
        user  nginx;
        worker_processes  5;  ## Default: 1

        events {
          worker_connections   1000;
        }

        http {
          resolver 127.0.0.11;

          server {
            listen             3100;

            location = / {
              return 200 'OK';
              auth_basic off;
            }

            location = /api/prom/push {
              proxy_pass       http://write:3100\$$request_uri;
            }

            location = /api/prom/tail {
              proxy_pass       http://read:3100\$$request_uri;
              proxy_set_header Upgrade \$$http_upgrade;
              proxy_set_header Connection "upgrade";
            }

            location ~ /api/prom/.* {
              proxy_pass       http://read:3100\$$request_uri;
            }

            location = /loki/api/v1/push {
              proxy_pass       http://write:3100\$$request_uri;
            }

            location = /loki/api/v1/tail {
              proxy_pass       http://read:3100\$$request_uri;
              proxy_set_header Upgrade \$$http_upgrade;
              proxy_set_header Connection "upgrade";
            }

            location ~ /loki/api/.* {
              proxy_pass       http://read:3100\$$request_uri;
            }
          }
        }
        EOF
        /docker-entrypoint.sh nginx -g "daemon off;"
    ports:
      - "3100:3100"
    healthcheck:
      test: ["CMD", "service", "nginx", "status"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - loki
  

  flog:
    image: mingrammer/flog
    command: -f json -d 200ms -l
    networks:
      - loki

  # Demo web application
  nginx:
    image: nginx:alpine
    container_name: demo-nginx
    ports:
      - "8080:80"
    networks:
      - loki
    restart: unless-stopped
```

**To use this example:**

```bash
# Start everything
docker-compose -f docker-compose-complete.yaml up -d

# Generate some web traffic to nginx
for i in {1..20}; do
  curl http://localhost:8080
  sleep 1
done

# View logs in Grafana
# Go to http://localhost:3000
# Click Explore
# Query: {container="demo-nginx"}
```

### 🧹 Cleanup

```bash
# Stop services
docker-compose down

# Stop and remove volumes (deletes all data)
docker-compose down -v

# Remove everything including images
docker-compose down -v --rmi all
```

---

## Installing Loki on Kubernetes

### ☸️ Kubernetes Deployment

Kubernetes deployments are better for:

- Production environments
- High-availability requirements
- Large-scale logging (100GB+/day)
- Multi-tenant applications

### Prerequisites

- Kubernetes cluster (v1.23+)
- kubectl configured
- Helm 3 installed
- At least 3 worker nodes (for HA)
- Storage class available

### Option 1: Quick Start (Monolithic Mode)

Perfect for small to medium workloads.

#### Step 1: Install Helm

```bash
# If you don't have Helm installed
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Verify installation
helm version
```

#### Step 2: Add Grafana Helm Repository

```bash
# Add the Grafana Helm repository
helm repo add grafana https://grafana.github.io/helm-charts

# Update repositories
helm repo update

# Search for available charts
helm search repo grafana/loki
```

#### Step 3: Create Namespace

```bash
# Create a dedicated namespace
kubectl create namespace loki-stack

# Set as default (optional)
kubectl config set-context --current --namespace=loki-stack
```

#### Step 4: Create Values File

Create `loki-values.yaml`:

```yaml
# Loki Configuration
loki:
  auth_enabled: false
  
  commonConfig:
    replication_factor: 1
  
  storage:
    type: 'filesystem'
  
  schemaConfig:
    configs:
      - from: "2024-01-01"
        store: tsdb
        object_store: filesystem
        schema: v13
        index:
          prefix: loki_index_
          period: 24h

# Use single binary deployment mode
deploymentMode: SingleBinary

singleBinary:
  replicas: 1
  persistence:
    enabled: true
    size: 10Gi
  resources:
    limits:
      cpu: 1000m
      memory: 1Gi
    requests:
      cpu: 100m
      memory: 128Mi

# Monitoring
monitoring:
  selfMonitoring:
    enabled: false
  lokiCanary:
    enabled: false

# Gateway (nginx)
gateway:
  enabled: true
  replicas: 1

# Test pod for querying
test:
  enabled: false
```

#### Step 5: Install Loki

```bash
# Install Loki with custom values
helm install loki grafana/loki \
  --namespace loki-stack \
  --values loki-values.yaml

# Check installation status
helm list -n loki-stack

# Watch pods coming up
kubectl get pods -n loki-stack -w
```

**Expected Output:**

```
NAME                            READY   STATUS    RESTARTS   AGE
loki-0                          1/1     Running   0          2m
loki-gateway-5d8f8b8c4d-xyz     1/1     Running   0          2m
```

#### Step 6: Install Grafana

Create `grafana-values.yaml`:

```yaml
# Admin credentials
adminUser: admin
adminPassword: admin123  # CHANGE THIS IN PRODUCTION!

# Persistence
persistence:
  enabled: true
  size: 5Gi

# Resources
resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 128Mi

# Datasources
datasources:
  datasources.yaml:
    apiVersion: 1
    datasources:
      - name: Loki
        type: loki
        access: proxy
        url: http://loki-gateway.loki-stack.svc.cluster.local
        isDefault: true
        jsonData:
          maxLines: 1000

# Service
service:
  type: NodePort
  port: 80
  nodePort: 30000  # Access via http://<node-ip>:30000

# Or use LoadBalancer for cloud
# service:
#   type: LoadBalancer
#   port: 80
```

Install Grafana:

```bash
# Install Grafana
helm install grafana grafana/grafana \
  --namespace loki-stack \
  --values grafana-values.yaml

# Get Grafana admin password (if not set in values)
kubectl get secret --namespace loki-stack grafana \
  -o jsonpath="{.data.admin-password}" | base64 --decode ; echo

# Check status
kubectl get pods -n loki-stack | grep grafana
```

#### Step 7: Install Alloy (Log Collection Agent)

Create `alloy-values.yaml`:

```yaml
alloy:
  configMap:
    content: |-
      logging {
        level  = "info"
        format = "logfmt"
      }

      // Kubernetes pod logs discovery
      discovery.kubernetes "pods" {
        role = "pod"
      }

      // Relabel and filter pods
      discovery.relabel "kubernetes_pods" {
        targets = discovery.kubernetes.pods.targets

        // Add namespace label
        rule {
          source_labels = ["__meta_kubernetes_namespace"]
          target_label  = "namespace"
        }

        // Add pod name label
        rule {
          source_labels = ["__meta_kubernetes_pod_name"]
          target_label  = "pod"
        }

        // Add container name label
        rule {
          source_labels = ["__meta_kubernetes_pod_container_name"]
          target_label  = "container"
        }
        
        // Set log path
        rule {
          source_labels = ["__meta_kubernetes_pod_uid", "__meta_kubernetes_pod_container_name"]
          separator     = "/"
          target_label  = "__path__"
          replacement   = "/var/log/pods/*$1/*.log"
        }
      }

      // Scrape container logs
      loki.source.kubernetes "pods" {
        targets    = discovery.relabel.kubernetes_pods.output
        forward_to = [loki.write.loki.receiver]
      }

      // Send to Loki
      loki.write "loki" {
        endpoint {
          url = "http://loki-gateway.loki-stack.svc.cluster.local/loki/api/v1/push"
        }
      }

controller:
  type: "daemonset"  # Deploy on every node

# Mount log directories
alloy:
  mounts:
    extra:
      - name: varlog
        mountPath: /var/log
        readOnly: true
      - name: varlibdockercontainers
        mountPath: /var/lib/docker/containers
        readOnly: true

  extraVolumes:
    - name: varlog
      hostPath:
        path: /var/log
    - name: varlibdockercontainers
      hostPath:
        path: /var/lib/docker/containers

# Resources
resources:
  limits:
    cpu: 200m
    memory: 256Mi
  requests:
    cpu: 50m
    memory: 64Mi
```

Install Alloy:

```bash
# Add Grafana helm repo if not already added
helm repo add grafana https://grafana.github.io/helm-charts

# Install Alloy
helm install alloy grafana/alloy \
  --namespace loki-stack \
  --values alloy-values.yaml

# Verify deployment
kubectl get daemonset -n loki-stack alloy
kubectl get pods -n loki-stack -l app.kubernetes.io/name=alloy
```

#### Step 8: Access Grafana

**Option 1: NodePort (already configured)**

```bash
# Get node IP
kubectl get nodes -o wide

# Access Grafana at: http://<NODE-IP>:30000
```

**Option 2: Port Forward**

```bash
# Forward Grafana to localhost
kubectl port-forward -n loki-stack svc/grafana 3000:80

# Access at: http://localhost:3000
# Login: admin / admin123
```

**Option 3: LoadBalancer (Cloud providers)**

```bash
# Get external IP
kubectl get svc -n loki-stack grafana

# Access via external IP
```

#### Step 9: Verify Everything Works

```bash
# Check all pods are running
kubectl get pods -n loki-stack

# Check Loki logs
kubectl logs -n loki-stack -l app.kubernetes.io/name=loki

# Check Alloy logs
kubectl logs -n loki-stack -l app.kubernetes.io/name=alloy

# Test Loki API
kubectl port-forward -n loki-stack svc/loki-gateway 3100:80
curl http://localhost:3100/ready
```

### Option 2: Production Setup (Simple Scalable Mode)

For larger deployments with better resource management.

Create `loki-production-values.yaml`:

```yaml
loki:
  auth_enabled: false
  
  commonConfig:
    replication_factor: 3  # High availability
  
  # Use S3 for storage (recommended for production)
  storage:
    type: 's3'
    bucketNames:
      chunks: my-loki-chunks-bucket
      ruler: my-loki-ruler-bucket
      admin: my-loki-admin-bucket
    s3:
      region: us-east-1
      # Use IAM roles or provide credentials
      # accessKeyId: <your-access-key>
      # secretAccessKey: <your-secret-key>
  
  schemaConfig:
    configs:
      - from: "2024-01-01"
        store: tsdb
        object_store: s3
        schema: v13
        index:
          prefix: loki_index_
          period: 24h

# Scalable deployment mode
deploymentMode: SimpleScalable

# Read component (queries)
read:
  replicas: 3
  persistence:
    enabled: true
    size: 10Gi
  resources:
    limits:
      cpu: 2
      memory: 2Gi
    requests:
      cpu: 500m
      memory: 512Mi

# Write component (ingestion)
write:
  replicas: 3
  persistence:
    enabled: true
    size: 10Gi
  resources:
    limits:
      cpu: 2
      memory: 2Gi
    requests:
      cpu: 500m
      memory: 512Mi

# Backend component (compaction, etc.)
backend:
  replicas: 3
  persistence:
    enabled: true
    size: 10Gi
  resources:
    limits:
      cpu: 1
      memory: 1Gi
    requests:
      cpu: 250m
      memory: 256Mi

# Gateway with autoscaling
gateway:
  enabled: true
  replicas: 2
  autoscaling:
    enabled: true
    minReplicas: 2
    maxReplicas: 6
    targetCPUUtilizationPercentage: 80
  resources:
    limits:
      cpu: 500m
      memory: 512Mi
    requests:
      cpu: 100m
      memory: 128Mi

# Monitoring
monitoring:
  selfMonitoring:
    enabled: true
    grafanaAgent:
      installOperator: false
  lokiCanary:
    enabled: true

# Service monitoring
serviceMonitor:
  enabled: true
```

Install:

```bash
# Install with production values
helm install loki grafana/loki \
  --namespace loki-stack \
  --values loki-production-values.yaml \
  --create-namespace

# Monitor the rollout
kubectl rollout status statefulset/loki-read -n loki-stack
kubectl rollout status statefulset/loki-write -n loki-stack
kubectl rollout status statefulset/loki-backend -n loki-stack
```

### 🎯 Deploy a Test Application

Let's deploy a simple app to generate logs:

```yaml
# Save as demo-app.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: demo-app
  namespace: loki-stack
spec:
  replicas: 3
  selector:
    matchLabels:
      app: demo-app
  template:
    metadata:
      labels:
        app: demo-app
    spec:
      containers:
      - name: logger
        image: busybox:latest
        command: 
          - sh
          - -c
          - |
            while true; do
              echo "$(date) - INFO - Application running normally"
              sleep 2
              echo "$(date) - DEBUG - Processing request from user_$(( RANDOM % 100 ))"
              sleep 1
              if [ $(( RANDOM % 10 )) -eq 0 ]; then
                echo "$(date) - ERROR - Failed to connect to database"
              fi
              sleep 3
            done
---
apiVersion: v1
kind: Service
metadata:
  name: demo-app
  namespace: loki-stack
spec:
  selector:
    app: demo-app
  ports:
  - port: 80
    targetPort: 80
```

Deploy:

```bash
# Apply the manifest
kubectl apply -f demo-app.yaml

# Check pods
kubectl get pods -n loki-stack -l app=demo-app

# View logs
kubectl logs -n loki-stack -l app=demo-app --tail=10
```

Now query these logs in Grafana:

```logql
# In Grafana Explore, try:
{namespace="loki-stack", app="demo-app"}

# Filter for errors:
{namespace="loki-stack", app="demo-app"} |= "ERROR"

# Count error rate:
rate({namespace="loki-stack", app="demo-app"} |= "ERROR" [5m])
```

### 📊 Kubernetes Architecture Diagram

```mermaid
graph TB
    subgraph "Kubernetes Cluster"
        subgraph "Application Pods"
            A1[Pod: demo-app-1]
            A2[Pod: demo-app-2]
            A3[Pod: demo-app-3]
        end
        
        subgraph "Log Collection - DaemonSet"
            B1[Alloy Node 1]
            B2[Alloy Node 2]
            B3[Alloy Node 3]
        end
        
        subgraph "Loki Components"
            C1[Write: Ingester<br/>StatefulSet]
            C2[Read: Query Frontend<br/>StatefulSet]
            C3[Backend: Compactor<br/>StatefulSet]
            C4[Gateway<br/>Deployment]
        end
        
        D[External Storage<br/>S3/GCS]
        
        A1 --> B1
        A2 --> B2
        A3 --> B3
        
        B1 --> C4
        B2 --> C4
        B3 --> C4
        
        C4 --> C1
        C4 --> C2
        
        C1 --> D
        C2 --> D
        C3 --> D
    end
    
    E[Grafana] --> C4
    F[Users] --> E
    
    style C1 fill:#ffd43b
    style C2 fill:#51cf66
    style C3 fill:#a78bfa
    style C4 fill:#ff6b6b
    style E fill:#4dabf7
```

### 🧹 Cleanup Kubernetes Resources

```bash
# Uninstall everything
helm uninstall loki -n loki-stack
helm uninstall grafana -n loki-stack
helm uninstall alloy -n loki-stack

# Delete demo app
kubectl delete -f demo-app.yaml

# Delete namespace (removes all resources)
kubectl delete namespace loki-stack

# Verify everything is gone
kubectl get all -n loki-stack
```

---

## Configuring Loki

### ⚙️ Understanding Configuration

Loki's configuration can seem complex, but we'll break it down into understandable chunks.

### Configuration Structure

```yaml
# Main configuration sections
├── server              # HTTP/GRPC server settings
├── distributor         # Incoming request handling
├── ingester           # Data buffering and storage
├── storage_config     # Storage backend configuration
├── schema_config      # Index schema definition
├── compactor          # Data compaction settings
├── limits_config      # Resource limits and quotas
└── query_range        # Query optimization settings
```

### Basic Configuration Template

```yaml
# auth_enabled - Enable multi-tenancy
# Think: "Do I need different teams to have separate log spaces?"
auth_enabled: false  # false = single tenant (simpler)

# Server configuration
server:
  http_listen_port: 3100      # Port for HTTP API
  grpc_listen_port: 9096      # Port for GRPC (internal)
  log_level: info             # debug, info, warn, error

# Common configuration (shared settings)
common:
  path_prefix: /loki           # Base directory for Loki
  replication_factor: 1        # How many copies of data (1-3)
  ring:
    kvstore:
      store: inmemory          # or: consul, etcd, memberlist
    instance_addr: 127.0.0.1

# Storage configuration
# Think: "Where should my log chunks be stored?"
storage:
  filesystem:
    directory: /loki/chunks    # Local storage path
  # Or use cloud storage:
  # aws:
  #   s3: s3://region/bucket
  #   dynamodb: region

# Schema configuration
# Think: "How should indexes be organized?"
schema_config:
  configs:
    - from: 2024-01-01         # Start date for this schema
      store: tsdb              # Index type (tsdb or boltdb)
      object_store: filesystem # Where chunks are stored
      schema: v13              # Schema version
      index:
        prefix: index_         # Index file prefix
        period: 24h            # How often to create new index

# Limits configuration
# Think: "How much can each tenant/user send?"
limits_config:
  # Ingestion limits
  ingestion_rate_mb: 10            # MB per second
  ingestion_burst_size_mb: 20      # Burst allowance
  max_streams_per_user: 10000      # Max unique label combinations
  max_entries_limit_per_query: 5000 # Max log lines per query
  
  # Retention
  retention_period: 744h           # 31 days (0 = forever)
  
  # Query limits
  max_query_length: 721h           # 30 days max query range
  max_query_parallelism: 32        # Parallel queries allowed

# Compactor configuration
# Think: "How should old data be cleaned up and optimized?"
compactor:
  working_directory: /loki/compactor
  shared_store: filesystem
  compaction_interval: 10m          # How often to compact
  retention_enabled: true           # Enable deletion of old logs
  retention_delete_delay: 2h        # Wait before deleting
  retention_delete_worker_count: 150

# Query optimization
query_range:
  results_cache:
    cache:
      embedded_cache:
        enabled: true               # Cache query results
        max_size_mb: 100            # Cache size
```

### Advanced Configurations

#### 1. Multi-Tenancy Configuration

```yaml
auth_enabled: true  # Enable multi-tenancy

# Distributor adds tenant ID from header
distributor:
  ring:
    kvstore:
      store: consul
      consul:
        host: consul:8500

# Limits per tenant
limits_config:
  per_tenant_override_config: /etc/loki/overrides.yaml
```

Create `overrides.yaml`:

```yaml
# Different limits for different tenants
overrides:
  tenant1:
    ingestion_rate_mb: 50
    max_streams_per_user: 50000
  
  tenant2:
    ingestion_rate_mb: 10
    max_streams_per_user: 10000
```

Send logs with tenant ID:

```bash
# Add X-Scope-OrgID header
curl -H "X-Scope-OrgID: tenant1" \
     -H "Content-Type: application/json" \
     -XPOST http://localhost:3100/loki/api/v1/push \
     --data '{"streams":[{"stream":{"job":"test"},"values":[["'"$(date +%s)000000000"'","test log"]]}]}'
```

#### 2. S3 Storage Configuration

```yaml
storage_config:
  aws:
    s3: s3://us-east-1/my-loki-bucket
    s3forcepathstyle: true        # For MinIO compatibility
    bucketnames: my-loki-bucket
    region: us-east-1
    access_key_id: ${AWS_ACCESS_KEY}
    secret_access_key: ${AWS_SECRET_KEY}
    
  tsdb_shipper:
    active_index_directory: /loki/index
    cache_location: /loki/index_cache
    cache_ttl: 24h

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: s3              # Changed from filesystem
      schema: v13
      index:
        prefix: loki_index_
        period: 24h
```

#### 3. High Availability Configuration

```yaml
common:
  replication_factor: 3           # 3 copies of each chunk

ingester:
  lifecycler:
    ring:
      kvstore:
        store: memberlist         # Self-organizing cluster
      replication_factor: 3
    num_tokens: 512               # More tokens = better distribution
    heartbeat_period: 5s
    join_after: 10s

memberlist:
  join_members:
    - loki-0.loki-headless:7946
    - loki-1.loki-headless:7946
    - loki-2.loki-headless:7946
```

#### 4. Performance Tuning

```yaml
# Optimize for high throughput
ingester:
  chunk_target_size: 1572864      # 1.5MB chunks
  chunk_idle_period: 30m          # Keep chunks in memory longer
  chunk_retain_period: 5m         # Overlap period for reads
  max_chunk_age: 2h               # Force flush after 2 hours
  wal:
    enabled: true                 # Write-ahead log
    dir: /loki/wal
    replay_memory_ceiling: 4GB

# Query optimization
query_range:
  align_queries_with_step: true   # Better caching
  split_queries_by_interval: 30m  # Break large queries
  cache_results: true
  
  results_cache:
    cache:
      embedded_cache:
        enabled: true
        max_size_mb: 500          # Larger cache

# Parallel processing
querier:
  max_concurrent: 20              # Concurrent queries
  query_timeout: 1m

query_scheduler:
  max_outstanding_requests_per_tenant: 2048
```

### Configuration Examples by Use Case

#### Small Development Environment

```yaml
# Perfect for local development
auth_enabled: false
server:
  http_listen_port: 3100

common:
  path_prefix: /tmp/loki
  replication_factor: 1
  storage:
    filesystem:
      chunks_directory: /tmp/loki/chunks
      rules_directory: /tmp/loki/rules

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: filesystem
      schema: v13

limits_config:
  ingestion_rate_mb: 4
  ingestion_burst_size_mb: 6
  retention_period: 168h  # 7 days
```

#### Medium Production (Single Binary)

```yaml
# Good for 100GB-1TB/day
auth_enabled: false
server:
  http_listen_port: 3100

common:
  path_prefix: /data/loki
  replication_factor: 1
  
storage_config:
  aws:
    s3: s3://us-east-1/production-logs
    region: us-east-1

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: s3
      schema: v13

limits_config:
  ingestion_rate_mb: 100
  ingestion_burst_size_mb: 200
  max_streams_per_user: 100000
  retention_period: 2160h  # 90 days

compactor:
  retention_enabled: true
  compaction_interval: 10m

query_range:
  split_queries_by_interval: 15m
  cache_results: true
```

#### Large Production (Microservices)

```yaml
# For TB+/day workloads
auth_enabled: true

# Shared configuration
common:
  replication_factor: 3
  
storage_config:
  aws:
    s3: s3://us-east-1/massive-logs
    region: us-east-1
  
  tsdb_shipper:
    active_index_directory: /data/loki/index
    cache_location: /data/loki/cache

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: s3
      schema: v13
      index:
        prefix: prod_loki_
        period: 24h

# Distributor configuration
distributor:
  ring:
    kvstore:
      store: memberlist

# Ingester configuration
ingester:
  chunk_target_size: 1572864
  chunk_idle_period: 30m
  max_chunk_age: 2h
  wal:
    enabled: true
    dir: /data/loki/wal

# Query optimization
querier:
  max_concurrent: 32
  engine:
    max_look_back_period: 168h

query_frontend:
  max_outstanding_per_tenant: 2048

query_scheduler:
  max_outstanding_requests_per_tenant: 4096

# Resource limits
limits_config:
  ingestion_rate_mb: 1000
  ingestion_burst_size_mb: 2000
  max_streams_per_user: 500000
  max_global_streams_per_user: 1000000
  retention_period: 4320h  # 180 days
  
  # Per tenant overrides
  per_tenant_override_config: /etc/loki/overrides.yaml

# Compactor
compactor:
  working_directory: /data/loki/compactor
  compaction_interval: 5m
  retention_enabled: true
  retention_delete_delay: 1h
  retention_delete_worker_count: 300
```

### 🔧 Configuration Testing

After changing configuration, always test:

```bash
# Test configuration syntax
loki -config.file=/etc/loki/config.yaml -config.verify-only

# Test Loki is working
curl http://localhost:3100/ready

# Check metrics
curl http://localhost:3100/metrics | grep loki

# Check ring status
curl http://localhost:3100/ring

# View current configuration
curl http://localhost:3100/config | jq
```

### Common Configuration Issues

#### Issue 1: Out of Memory

**Symptom:** Loki crashes with OOM

```yaml
# Solution: Limit memory usage
limits_config:
  max_query_lookback: 168h        # Limit query time range
  max_entries_limit_per_query: 5000
  
ingester:
  chunk_target_size: 1048576      # Smaller chunks (1MB)
  chunk_retain_period: 1m         # Flush faster
```

#### Issue 2: Slow Queries

**Symptom:** Queries timeout

```yaml
# Solution: Optimize queries
query_range:
  split_queries_by_interval: 15m  # Break into chunks
  parallelise_shardable_queries: true
  
querier:
  max_concurrent: 10              # More parallel queries

limits_config:
  max_query_parallelism: 32       # Per tenant
```

#### Issue 3: High Cardinality

**Symptom:** Too many unique label combinations

```yaml
# Solution: Limit streams
limits_config:
  max_streams_per_user: 10000
  reject_old_samples: true
  reject_old_samples_max_age: 168h
  
  # Drop high-cardinality labels at ingestion
  # Configure in Promtail/Alloy instead
```

---

## Visualizing Logs with Grafana

### 📊 Grafana Integration

Grafana is your window into Loki - it's where you'll spend most of your time querying and visualizing logs.

### Setting Up Grafana

#### Step 1: Add Loki as Data Source

**Via UI:**

1. Go to Grafana (<http://localhost:3000>)
2. Click on Configuration (⚙️) → Data Sources
3. Click "Add data source"
4. Select "Loki"
5. Configure:
   - **Name:** Loki
   - **URL:** `http://loki:3100` (Docker) or `http://loki-gateway:80` (Kubernetes)
   - **Access:** Server (default)
6. Click "Save & Test"

**Via Configuration File:**

Create `datasource.yaml`:

```yaml
apiVersion: 1

datasources:
  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    isDefault: true
    version: 1
    editable: false
    jsonData:
      maxLines: 1000
      derivedFields:
        # Extract trace IDs
        - datasourceUid: tempo
          matcherRegex: "trace_id=(\\w+)"
          name: TraceID
          url: "$${__value.raw}"
```

### Explore Interface

The Explore interface is where you'll start:

```mermaid
graph TD
    A[Grafana Explore] --> B[Data Source Selector]
    A --> C[Query Builder]
    A --> D[Log Browser]
    A --> E[Results Panel]
    
    C --> F[Label Filters]
    C --> G[Line Filters]
    C --> H[Parser Expressions]
    C --> I[Label Format]
    
    E --> J[Log Viewer]
    E --> K[Graph View]
    E --> L[Table View]
    
    style A fill:#4dabf7
    style C fill:#51cf66
    style E fill:#ffd43b
```

### Explore Features

#### 1. Log Browser

The easiest way to start - browse available labels:

1. Click "Log browser" button
2. Select labels to filter:
   - `job`: Application or service name
   - `namespace`: Kubernetes namespace
   - `container`: Container name
   - `level`: Log level (info, error, debug)

#### 2. Query Builder

Build queries without writing LogQL:

1. Click "+ Add filter"
2. Select label name
3. Select operator (=, !=, =~, !~)
4. Enter value
5. Click "+" to add more filters

Example:

```
Label: job = "nginx"
Label: level = "error"
```

This creates: `{job="nginx", level="error"}`

#### 3. Label Stats

See statistics about your logs:

- Click "Show logs volume" to see log rate over time
- Click on any label value to filter
- Use the histogram to zoom into time ranges

### Creating Dashboards

Let's create a complete monitoring dashboard!

#### Example Dashboard: Application Monitoring

Create `dashboard.json`:

```json
{
  "dashboard": {
    "title": "Application Logs Dashboard",
    "rows": [
      {
        "title": "Overview",
        "panels": [
          {
            "title": "Log Volume",
            "type": "graph",
            "targets": [
              {
                "expr": "sum(rate({job=\"myapp\"}[1m]))",
                "legendFormat": "Total Logs/sec"
              }
            ]
          },
          {
            "title": "Error Rate",
            "type": "graph",
            "targets": [
              {
                "expr": "sum(rate({job=\"myapp\"} |= \"ERROR\" [5m]))",
                "legendFormat": "Errors/sec"
              }
            ]
          },
          {
            "title": "Log Level Distribution",
            "type": "piechart",
            "targets": [
              {
                "expr": "sum by (level) (count_over_time({job=\"myapp\"} | logfmt [1h]))"
              }
            ]
          }
        ]
      }
    ]
  }
}
```

Import:

```bash
curl -X POST http://admin:admin@localhost:3000/api/dashboards/db \
  -H "Content-Type: application/json" \
  -d @dashboard.json
```

#### Panel Examples

**1. Recent Logs Table**

```logql
{namespace="production", job="api"}
```

Panel Settings:

- Visualization: Table
- Show: Last 100 lines
- Columns: Time, Line

**2. Error Rate Graph**

```logql
sum(rate({namespace="production"} |= "error" [5m])) by (job)
```

Panel Settings:

- Visualization: Time series
- Unit: Logs per second
- Show: Legend, Tooltip

**3. Slow Query Detection**

```logql
{job="database"} 
  | logfmt 
  | duration > 5s
```

Panel Settings:

- Visualization: Table
- Transform: Extract fields
- Show: Time, Query, Duration

**4. HTTP Status Codes**

```logql
sum by (status) (
  count_over_time(
    {job="nginx"} 
      | regexp "HTTP/\\d\\.\\d\\\" (?P<status>\\d{3})"
    [5m]
  )
)
```

Panel Settings:

- Visualization: Bar chart
- Show: Status codes distribution

**5. Top Errors**

```logql
topk(10,
  sum by (error_msg) (
    count_over_time(
      {job="app"} 
        |= "ERROR" 
        | logfmt 
        | error_msg != ""
      [1h]
    )
  )
)
```

Panel Settings:

- Visualization: Stat/Table
- Show: Top 10 error messages with counts

### Advanced Visualizations

#### Heatmap for Response Times

```logql
quantile_over_time(0.95,
  {job="api"} 
    | logfmt 
    | unwrap duration [5m]
) by (endpoint)
```

Settings:

- Visualization: Heatmap
- Color: Green to Red
- Y-axis: Response time (ms)
- X-axis: Time

#### Correlation with Traces

If using Tempo for traces:

```logql
{job="api"} 
  | logfmt 
  | trace_id != ""
```

Settings:

- Enable "Data links"
- Link to Tempo: `${__value.raw}`
- Click trace ID to jump to trace

### Dashboard Best Practices

#### 1. Dashboard Structure

```
┌─────────────────────────────────────────┐
│  Dashboard Title & Time Range          │
├─────────────────────────────────────────┤
│  📊 Overview Row                        │
│  ┌───────┐ ┌───────┐ ┌───────┐       │
│  │ Total │ │ Errors│ │ Warn  │       │
│  │ Logs  │ │ Count │ │ Count │       │
│  └───────┘ └───────┘ └───────┘       │
├─────────────────────────────────────────┤
│  📈 Trends Row                          │
│  ┌─────────────────┐ ┌───────────┐   │
│  │ Log Volume      │ │ Error Rate│   │
│  │ Time Series     │ │ Graph     │   │
│  └─────────────────┘ └───────────┘   │
├─────────────────────────────────────────┤
│  📋 Details Row                         │
│  ┌─────────────────────────────────┐  │
│  │ Recent Logs Table               │  │
│  │                                 │  │
│  └─────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

#### 2. Variable Templates

Make dashboards dynamic with variables:

```
# In Dashboard Settings → Variables

Name: namespace
Type: Query
Query: label_values(namespace)

Name: job  
Type: Query
Query: label_values({namespace="$namespace"}, job)

Name: level
Type: Custom
Values: INFO,WARN,ERROR,DEBUG
```

Use in queries:

```logql
{namespace="$namespace", job="$job", level="$level"}
```

#### 3. Alert Rules

Create alerts for critical issues:

**Alert: High Error Rate**

```logql
sum(rate({job="api"} |= "ERROR" [5m])) > 10
```

Alert Config:

- Evaluate every: 1m
- For: 5m (after 5 minutes)
- Annotations:
  - Summary: High error rate detected
  - Description: {{ $value }} errors/sec

### Grafana Shortcuts & Tips

#### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl/Cmd + K` | Open search |
| `Ctrl/Cmd + S` | Save dashboard |
| `Ctrl/Cmd + E` | Toggle edit mode |
| `Ctrl/Cmd + H` | Hide/show panel menu |
| `d` then `n` | New dashboard |
| `d` then `s` | Dashboard settings |
| `?` | Show shortcuts |

#### Query Tips

```logql
# Use time range presets
{job="api"}  # Last 6 hours (default)

# Relative time
{job="api"}[5m]  # Last 5 minutes

# Use regex efficiently
{job=~"api|web"}  # Match multiple values

# Combine filters
{job="api"} 
  |= "error"      # Must contain "error"
  != "timeout"    # Must not contain "timeout"
  |~ "user_\\d+"  # Regex match

# Use parser for structured logs
{job="api"} 
  | json
  | status_code >= 500

# Format output
{job="api"} 
  | json 
  | line_format "{{.timestamp}} {{.level}}: {{.message}}"
```

---

## LogQL - Query Language

### 🔍 Understanding LogQL

LogQL is Loki's query language - think of it as SQL for logs, but inspired by Prometheus's PromQL.

### Query Structure

Every LogQL query has two parts:

```mermaid
graph LR
    A[LogQL Query] --> B[Log Stream Selector<br/>{job='api'}]
    A --> C[Log Pipeline<br/>|= 'error' | json]
    
    B --> D[Selects which logs<br/>to look at]
    C --> E[Filters and processes<br/>the logs]
    
    style B fill:#51cf66
    style C fill:#ffd43b
```

### Part 1: Log Stream Selectors

#### Basic Selectors

Think of selectors as picking which boxes to open:

```logql
# Single label - exact match
{job="nginx"}

# Multiple labels - AND condition
{job="nginx", env="production"}

# Regex match
{job=~"api|web"}

# Negative regex
{job!~"test.*"}

# NOT equal
{job!="debug-service"}
```

#### Label Operators

| Operator | Meaning | Example |
|----------|---------|---------|
| `=` | Equals (exact match) | `{job="nginx"}` |
| `!=` | Not equals | `{job!="test"}` |
| `=~` | Regex match | `{job=~"api-.*"}` |
| `!~` | Regex not match | `{job!~"test-.*"}` |

### Part 2: Log Pipeline

The pipeline processes logs step by step, left to right:

```logql
{job="api"} 
  |= "error"          # Step 1: Filter containing "error"
  | json              # Step 2: Parse as JSON
  | status >= 500     # Step 3: Filter status codes
  | line_format "{{.timestamp}}: {{.message}}"  # Step 4: Format output
```

### Line Filters

Filter logs based on content:

```logql
# Contains (case-sensitive)
{job="app"} |= "error"

# Does not contain
{job="app"} != "debug"

# Regex match
{job="app"} |~ "error|exception"

# Regex not match
{job="app"} !~ "info|debug"
```

**Multiple filters (AND logic):**

```logql
{job="app"} 
  |= "error"          # Must contain "error"
  != "connection"     # Must NOT contain "connection"
  |~ "user_\\d+"      # Must match this regex
```

### Parsers

Extract structured data from logs:

#### JSON Parser

For logs in JSON format:

```json
{"timestamp":"2025-10-30T10:00:00Z","level":"ERROR","message":"Database connection failed","user_id":123}
```

```logql
# Parse JSON and create labels
{job="app"} | json

# Now you can filter on extracted fields
{job="app"} 
  | json 
  | level="ERROR"
  | user_id > 100
```

#### Logfmt Parser

For key=value formatted logs:

```
timestamp=2025-10-30T10:00:00Z level=ERROR message="Connection timeout" user_id=123
```

```logql
{job="app"} | logfmt

# Filter on parsed fields
{job="app"} 
  | logfmt 
  | level="ERROR"
  | user_id != ""
```

#### Pattern Parser

For consistent log formats:

```
192.168.1.1 - - [30/Oct/2025:10:00:00 +0000] "GET /api/users HTTP/1.1" 200 1234
```

```logql
{job="nginx"} 
  | pattern `<ip> - - [<timestamp>] "<method> <path> <protocol>" <status> <size>`

# Now use extracted fields
{job="nginx"} 
  | pattern `<ip> - - [<_>] "<method> <_>" <status> <_>`
  | status >= 400
```

#### Regexp Parser

For complex patterns:

```logql
{job="app"} 
  | regexp `(?P<timestamp>\d{4}-\d{2}-\d{2}) (?P<level>\w+): (?P<message>.*)`

# Use named groups as labels
{job="app"} 
  | regexp `level=(?P<level>\w+)`
  | level="ERROR"
```

### Label Filters

After parsing, filter on labels:

```logql
# Numeric comparisons
{job="app"} | json | response_time > 1000

# String equality
{job="app"} | json | status_code = "500"

# IP address filters
{job="nginx"} | logfmt | ip != ip("192.168.0.0/16")

# Duration comparisons
{job="api"} | logfmt | duration > 5s
```

**Operators:**

| Type | Operators | Example |
|------|-----------|---------|
| Comparison | `>`, `>=`, `<`, `<=`, `==`, `!=` | `status >= 500` |
| Regex | `=~`, `!~` | `message =~ "error.*"` |
| Special | `ip()` | `ip != ip("10.0.0.0/8")` |

### Line Format Expressions

Reformat log lines:

```logql
# Simple template
{job="app"} 
  | json 
  | line_format "{{.level}}: {{.message}}"

# With functions
{job="nginx"} 
  | logfmt 
  | line_format "{{.method}} {{.path}} - {{.status}} ({{.duration | printf \"%.2f\"}}ms)"

# Conditional formatting
{job="app"} 
  | json 
  | line_format "{{if eq .level \"ERROR\"}}🔴{{else}}✅{{end}} {{.message}}"
```

### Label Format Expressions

Add or modify labels:

```logql
# Add new label
{job="app"} 
  | json 
  | label_format new_label="value"

# Rename label
{job="app"} 
  | json 
  | label_format renamed={{.old_name}}

# Calculate new label
{job="app"} 
  | json 
  | label_format duration_seconds="{{div .duration_ms 1000}}"

# Conditional label
{job="app"} 
  | json 
  | label_format priority="{{if gt .status 500}}high{{else}}normal{{end}}"
```

### Unwrap Expressions

Extract numeric values for metric queries:

```logql
# Unwrap a duration field
{job="api"} 
  | json 
  | unwrap duration

# Unwrap with unit conversion
{job="api"} 
  | logfmt 
  | unwrap duration_ms | __error__=""
```

Use with metric queries:

```logql
# Average response time
avg_over_time(
  {job="api"} 
    | json 
    | unwrap response_time [5m]
)

# 95th percentile
quantile_over_time(0.95,
  {job="api"} 
    | json 
    | unwrap duration [5m]
)
```

### Metric Queries

Convert logs into metrics:

#### Range Vector Aggregations

```logql
# Count logs per second
rate({job="api"}[5m])

# Count matching logs
count_over_time({job="api"} |= "error" [5m])

# Bytes processed
bytes_over_time({job="api"}[5m])

# Bytes per second
bytes_rate({job="api"}[5m])
```

#### Aggregation Functions

```logql
# Sum across all series
sum(rate({job="api"}[5m]))

# Sum by label
sum by (status) (
  rate({job="api"} | json [5m])
)

# Average
avg(
  avg_over_time(
    {job="api"} | json | unwrap response_time [5m]
  )
)

# Count distinct
count(
  count_over_time({namespace="prod"}[5m]) > 0
)

# Top 5
topk(5,
  sum by (endpoint) (
    rate({job="api"} [5m])
  )
)
```

#### Statistical Functions

```logql
# Min/Max
max_over_time(
  {job="api"} | json | unwrap duration [5m]
)

# Standard deviation
stddev_over_time(
  {job="api"} | json | unwrap response_time [5m]
)

# Quantiles (percentiles)
quantile_over_time(0.95,
  {job="api"} | json | unwrap duration [5m]
)

# Multi-quantile
quantile_over_time(0.50,
  {job="api"} | json | unwrap duration [5m]
)
```

### Practical Query Examples

#### Example 1: Error Monitoring

```logql
# Count errors per minute
sum(rate({namespace="production"} |= "ERROR" [1m]))

# Errors by service
sum by (job) (
  rate({namespace="production"} |= "ERROR" [5m])
)

# Top error messages
topk(10,
  sum by (error_msg) (
    count_over_time(
      {namespace="production"} 
        |= "ERROR" 
        | json 
        | error_msg != "" [1h]
    )
  )
)
```

#### Example 2: Performance Analysis

```logql
# Average response time
avg(
  avg_over_time(
    {job="api"} 
      | json 
      | unwrap response_time_ms [5m]
  )
) by (endpoint)

# 95th percentile response time
quantile_over_time(0.95,
  {job="api"} 
    | json 
    | unwrap response_time_ms [5m]
) by (endpoint)

# Slow requests (> 1 second)
{job="api"} 
  | json 
  | duration > 1000
  | line_format "{{.timestamp}}: {{.endpoint}} took {{.duration}}ms"
```

#### Example 3: User Activity

```logql
# Unique users per hour
count(
  count by (user_id) (
    count_over_time(
      {job="api"} | json | user_id != "" [1h]
    )
  )
)

# Top active users
topk(20,
  sum by (user_id) (
    count_over_time(
      {job="api"} | json | user_id != "" [24h]
    )
  )
)

# User actions
{job="api"} 
  | json 
  | user_id="12345"
  | line_format "{{.timestamp}}: {{.action}} - {{.resource}}"
```

#### Example 4: Security Monitoring

```logql
# Failed login attempts
{job="auth"} 
  |= "login failed" 
  | json 
  | line_format "{{.ip}} tried to login as {{.username}}"

# Suspicious IPs (>10 failed logins/min)
sum by (ip) (
  rate(
    {job="auth"} 
      |= "login failed" 
      | json [1m]
  )
) > 10

# Geographic distribution
sum by (country) (
  count_over_time(
    {job="api"} 
      | json 
      | country != "" [1h]
  )
)
```

#### Example 5: Debugging Specific Issues

```logql
# Find logs for specific request
{job="api"} 
  | json 
  | request_id="abc-123-xyz"

# Trace entire user session
{job="api"} 
  | json 
  | session_id="sess_789"
  | line_format "{{.timestamp}} [{{.level}}] {{.message}}"

# Database query performance
{job="api"} 
  |~ "query took" 
  | regexp "query took (?P<duration>\\d+)ms"
  | duration > 1000
```

### LogQL Cheat Sheet

```logql
# ============================================
# STREAM SELECTORS
# ============================================
{job="api"}                          # Exact match
{job="api", env="prod"}              # Multiple labels (AND)
{job=~"api|web"}                     # Regex match
{job!="test"}                        # Not equal

# ============================================
# LINE FILTERS
# ============================================
|= "error"                           # Contains
!= "debug"                           # Not contains
|~ "error|exception"                 # Regex match
!~ "info|debug"                      # Regex not match

# ============================================
# PARSERS
# ============================================
| json                               # Parse JSON
| logfmt                             # Parse key=value
| regexp "pattern"                   # Parse with regex
| pattern `<ip> - <time>`           # Pattern extraction

# ============================================
# LABEL FILTERS
# ============================================
| status >= 500                      # Numeric
| level = "ERROR"                    # String
| ip != ip("10.0.0.0/8")            # IP range
| duration > 5s                      # Duration

# ============================================
# FORMATTING
# ============================================
| line_format "{{.field}}"          # Format line
| label_format new={{.old}}         # Format label
| unwrap field                       # Extract number

# ============================================
# METRIC QUERIES
# ============================================
rate({job="api"}[5m])               # Rate per second
count_over_time({job="api"}[5m])    # Count
sum by (label) (rate(...))          # Aggregate
avg_over_time(...[5m])              # Average
quantile_over_time(0.95, ...[5m])   # Percentile
topk(10, ...)                       # Top N
```

---

## Real-World Examples

### 🎮 Practical Scenarios

Let's put everything together with real-world examples you can actually run!

### Example 1: E-Commerce Application Monitoring

#### Scenario

You have an e-commerce platform with:

- Web frontend
- API backend
- Payment service
- Inventory service

#### Setup

Create `ecommerce-stack.yaml`:

```yaml
version: '3.8'

networks:
  ecommerce:

services:
  # Loki
  loki:
    image: grafana/loki:3.5.7
    ports:
      - "3100:3100"
    command: -config.file=/etc/loki/local-config.yaml
    networks:
      - ecommerce

  # Grafana
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
    networks:
      - ecommerce

  # Alloy
  alloy:
    image: grafana/alloy:latest
    volumes:
      - ./alloy-local-config.yaml:/etc/alloy/config.alloy
      - /var/run/docker.sock:/var/run/docker.sock:ro
    command:
      - run
      - /etc/alloy/config.alloy
    depends_on:
      - loki
    networks:
      - ecommerce

  # Frontend service
  frontend:
    image: nginx:alpine
    labels:
      logging: "promtail"
      service: "frontend"
    networks:
      - ecommerce

  # API service (simulated with log generator)
  api:
    image: mingrammer/flog
    command:
      - -f
      - json
      - -l
      - -d
      - 500ms
      - -o
      - /var/log/api.log
      - -t
      - log
      - -w
    volumes:
      - ./logs:/var/log
    labels:
      logging: "promtail"
      service: "api"
    networks:
      - ecommerce

  # Payment service
  payment:
    image: busybox
    command:
      - sh
      - -c
      - |
        while true; do
          STATUS=$((RANDOM % 10))
          if [ $$STATUS -eq 0 ]; then
            echo "{\"timestamp\":\"$$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"level\":\"ERROR\",\"service\":\"payment\",\"message\":\"Payment processing failed\",\"transaction_id\":\"txn_$$RANDOM\",\"amount\":$$((RANDOM % 1000))}"
          else
            echo "{\"timestamp\":\"$$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"level\":\"INFO\",\"service\":\"payment\",\"message\":\"Payment processed successfully\",\"transaction_id\":\"txn_$$RANDOM\",\"amount\":$$((RANDOM % 1000))}"
          fi
          sleep 1
        done
    labels:
      logging: "promtail"
      service: "payment"
    networks:
      - ecommerce

  # Inventory service
  inventory:
    image: busybox
    command:
      - sh
      - -c
      - |
        while true; do
          LEVEL=$$(( RANDOM % 4 ))
          case $$LEVEL in
            0) LEVEL_STR="DEBUG" ;;
            1) LEVEL_STR="INFO" ;;
            2) LEVEL_STR="WARN" ;;
            3) LEVEL_STR="ERROR" ;;
          esac
          echo "{\"timestamp\":\"$$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"level\":\"$$LEVEL_STR\",\"service\":\"inventory\",\"message\":\"Stock check\",\"product_id\":\"prod_$$((RANDOM % 100))\",\"stock\":$$((RANDOM % 500))}"
          sleep 2
        done
    labels:
      logging: "promtail"
      service: "inventory"
    networks:
      - ecommerce
```

#### Dashboard Queries

**1. Service Health Overview**

```logql
# Total requests per service
sum by (service) (rate({job=~".*"}[5m]))

# Error rate by service
sum by (service) (
  rate({job=~".*"} |= "ERROR" [5m])
)

# Success rate
(
  sum by (service) (rate({job=~".*"}[5m]))
  -
  sum by (service) (rate({job=~".*"} |= "ERROR" [5m]))
) / 
sum by (service) (rate({job=~".*"}[5m]))
* 100
```

**2. Payment Monitoring**

```logql
# Payment success rate
sum(
  rate({service="payment"} |= "successfully" [5m])
) /
sum(
  rate({service="payment"} [5m])
) * 100

# Failed payments details
{service="payment"} 
  |= "failed" 
  | json 
  | line_format "{{.timestamp}}: Transaction {{.transaction_id}} failed - Amount: ${{.amount}}"

# Payment volume
sum(
  count_over_time({service="payment"} [1m])
)
```

**3. Inventory Alerts**

```logql
# Low stock alerts
{service="inventory"} 
  | json 
  | stock < 10
  | line_format "⚠️ Low stock: Product {{.product_id}} has only {{.stock}} units"

# Stock by product
sum by (product_id) (
  avg_over_time(
    {service="inventory"} 
      | json 
      | unwrap stock [5m]
  )
)
```

### Example 2: Microservices Troubleshooting

#### Scenario

Debug a distributed transaction across multiple services.

#### Correlation with Trace IDs

```logql
# Step 1: Find the failing request
{namespace="production"} 
  |= "ERROR" 
  |= "order processing"
  | json
  | line_format "TraceID: {{.trace_id}} - {{.message}}"

# Step 2: Get the trace ID and track it across services
{namespace="production"} 
  | json 
  | trace_id="abc-123-xyz"
  | line_format "[{{.service}}] {{.timestamp}}: {{.message}}"
```

#### Timeline Reconstruction

```logql
# Reconstruct what happened
{namespace="production"} 
  | json 
  | request_id="req_123"
  | line_format "{{.timestamp}} [{{.service}}] {{.level}}: {{.message}}"
```

### Example 3: Security Monitoring

#### Create Security Dashboard

**1. Failed Login Detection**

```logql
# Failed logins
{job="auth"} 
  |= "login" 
  |= "failed" 
  | json
  | line_format "{{.ip}} failed login for user {{.username}}"

# Brute force detection (>5 failures in 1 minute)
sum by (ip) (
  count_over_time(
    {job="auth"} 
      |= "login failed" 
      | json [1m]
  )
) > 5
```

**2. Unusual API Usage**

```logql
# Requests from unknown IPs
{job="api"} 
  | json 
  | ip !~ "10\\..*|192\\.168\\..*"

# High request rate (potential DDoS)
sum by (ip) (
  rate({job="api"} [1m])
) > 100
```

**3. Privilege Escalation Attempts**

```logql
# Unauthorized access attempts
{job="api"} 
  | json 
  | status_code = "403"
  | line_format "{{.ip}} attempted to access {{.endpoint}}"

# Admin actions
{job="api"} 
  |= "admin" 
  | json 
  | action != "login"
  | line_format "Admin action: {{.user}} performed {{.action}} on {{.resource}}"
```

### Example 4: Cost Optimization

#### Identify Expensive Queries

```logql
# Slow database queries
{job="api"} 
  |~ "query took" 
  | regexp "query took (?P<duration>\\d+)ms"
  | duration > 1000
  | label_format duration_sec="{{div .duration 1000}}"
  | line_format "Slow query ({{.duration_sec}}s): {{.query}}"

# Most expensive endpoints
avg by (endpoint) (
  avg_over_time(
    {job="api"} 
      | json 
      | unwrap response_time_ms [1h]
  )
)
```

### Example 5: DevOps Automation

#### Deployment Monitoring

```logql
# Detect new deployments
{job="kubernetes"} 
  |= "Pod" 
  |= "Started"
  | json
  | line_format "New pod deployed: {{.pod_name}}"

# Post-deployment error spike
rate({namespace="production"} |= "ERROR" [5m])
```

#### Resource Usage

```logql
# OOM kills
{job="kubernetes"} 
  |= "OOMKilled"
  | json
  | line_format "OOM Kill: {{.pod_name}} in {{.namespace}}"

# Container restarts
{job="kubernetes"} 
  |= "restarting"
  | json
  | line_format "Restart detected: {{.container}} ({{.restart_count}} times)"
```

### Complete Working Demo

Here's a complete setup you can run:

```bash
# 1. Create directory
mkdir loki-demo && cd loki-demo

# 2. Download configuration
wget https://raw.githubusercontent.com/grafana/loki/main/cmd/loki/loki-local-config.yaml

# 3. Create docker-compose.yaml
cat > docker-compose.yaml << 'EOF'
version: '3.8'
networks:
  loki:
services:
  loki:
    image: grafana/loki:3.5.7
    ports:
      - "3100:3100"
    command: -config.file=/etc/loki/local-config.yaml
    networks:
      - loki

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
    networks:
      - loki

  app-logs:
    image: mingrammer/flog
    command: -f json -l -d 1s
    networks:
      - loki

  alloy:
    image: grafana/alloy:latest
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - ./alloy-local-config.yaml:/etc/alloy/config.alloy
    command: run /etc/alloy/config.alloy
    depends_on:
      - loki
    networks:
      - loki
EOF

# 4. Create Alloy config
cat > alloy-local-config.yaml << 'EOF'
// Scrape logs from Docker containers
discovery.docker "docker_scraper" {
  host             = "unix:///var/run/docker.sock"
  refresh_interval = "5s"
}

discovery.relabel "docker_scraper" {
  targets = []

  rule {
    source_labels = ["__meta_docker_container_name"]
    regex         = "/(.*)"
    target_label  = "container"
  }
}

loki.source.docker "docker_scraper" {
  host             = "unix:///var/run/docker.sock"
  targets          = discovery.docker.docker_scraper.targets
  forward_to       = [loki.write.default.receiver]
  relabel_rules    = discovery.relabel.docker_scraper.rules
  refresh_interval = "5s"
}

loki.write "default" {
  endpoint {
    url       = "http://gateway:3100/loki/api/v1/push"
    tenant_id = "tenant1"
  }
  external_labels = {}
}

EOF

# 5. Start everything
docker-compose up -d

# 6. Wait for services to start
sleep 10

# 7. Access Grafana
echo "Open http://localhost:3000"
echo "Go to Explore and query: {container=\"app-logs\"}"
```

---

## Best Practices

### 🎯 Production Guidelines

#### 1. Label Strategy

**DO:**

```yaml
# Good labels - Low cardinality
labels:
  - job: "api-server"
  - environment: "production"
  - region: "us-east"
  - level: "error"
```

**DON'T:**

```yaml
# Bad labels - High cardinality
labels:
  - user_id: "12345"          # Unique per user
  - request_id: "abc-123"     # Unique per request
  - timestamp: "2025..."      # Always unique
  - ip_address: "1.2.3.4"     # Too many values
```

**Why?** Each unique combination of labels creates a new stream. High cardinality = too many streams = poor performance.

**Solution:**

```logql
# Don't use as label, extract during query
{job="api"} 
  | json 
  | user_id="12345"  # Filter after parsing
```

#### 2. Retention Policy

```yaml
# Set appropriate retention based on volume
limits_config:
  retention_period: 744h  # 31 days

# Enable compaction
compactor:
  retention_enabled: true
  retention_delete_delay: 2h
```

**Retention Guidelines:**

| Log Type | Suggested Retention |
|----------|---------------------|
| Debug logs | 7 days |
| Application logs | 30 days |
| Audit logs | 90-365 days |
| Security logs | 365+ days |

#### 3. Resource Planning

**Ingester Memory:**

```
Required Memory = Daily Log Volume × Chunk Target Size × Replication Factor
                 / (86400 × Flush Interval)

Example:
100GB/day × 1.5MB × 3 / (86400 × 300s) = ~1.7GB
```

**Storage:**

```
Storage Needed = Daily Volume × Retention Days × Compression Ratio

Example:
100GB/day × 30 days × 0.1 (10:1 compression) = 300GB
```

#### 4. Query Optimization

**DO:**

```logql
# Efficient - filters early
{job="api", environment="prod"} 
  |= "error" 
  | json 
  | status >= 500

# Use time range limits
{job="api"}[1h]  # Not [30d]
```

**DON'T:**

```logql
# Inefficient - processes too much
{job="api"} 
  | json               # Parses everything
  | environment="prod" # Filters after parsing

# Avoid huge time ranges
{job="api"}[365d]  # Very slow
```

#### 5. Monitoring Loki Itself

```yaml
# Enable self-monitoring
monitoring:
  selfMonitoring:
    enabled: true
```

**Key Metrics to Watch:**

```logql
# Ingestion rate
sum(rate(loki_distributor_bytes_received_total[5m]))

# Query latency
histogram_quantile(0.99, 
  rate(loki_query_duration_seconds_bucket[5m])
)

# Failed requests
rate(loki_request_duration_seconds_count{status_code=~"5.."}[5m])
```

#### 6. Security Best Practices

```yaml
# Enable authentication
auth_enabled: true

# Use TLS
server:
  http_tls_config:
    cert_file: /path/to/cert.pem
    key_file: /path/to/key.pem

# Rate limiting
distributor:
  rate_limit_per_second: 100

# Tenant limits
limits_config:
  ingestion_rate_mb: 10
  max_streams_per_user: 10000
```

#### 7. Backup Strategy

```bash
# Backup configuration
tar -czf loki-config-backup.tar.gz /etc/loki/

# For object storage (S3), enable versioning
aws s3api put-bucket-versioning \
  --bucket my-loki-bucket \
  --versioning-configuration Status=Enabled
```

---

## Troubleshooting

### 🔧 Common Issues and Solutions

#### Issue 1: Logs Not Appearing

**Symptom:** No logs show up in Grafana

**Check:**

```bash
# 1. Is Alloy/Promtail running?
docker ps | grep alloy
kubectl get pods -n loki-stack | grep alloy

# 2. Check Alloy logs
docker logs alloy
kubectl logs -n loki-stack -l app.kubernetes.io/name=alloy

# 3. Is Loki receiving logs?
curl http://localhost:3100/metrics | grep loki_distributor_bytes_received_total

# 4. Check Loki logs
docker logs loki
kubectl logs -n loki-stack -l app.kubernetes.io/name=loki
```

**Solution:**

```yaml
# Verify Alloy config has correct Loki URL
loki.write "loki" {
  endpoint {
    url = "http://loki:3100/loki/api/v1/push"  # Correct URL?
  }
}
```

#### Issue 2: Out of Memory

**Symptom:** Loki crashes with OOM

**Check:**

```bash
# Check memory usage
docker stats loki
kubectl top pod -n loki-stack

# Check Loki metrics
curl http://localhost:3100/metrics | grep go_memstats
```

**Solution:**

```yaml
# Reduce memory usage
limits_config:
  max_query_lookback: 168h        # Limit query range
  max_entries_limit_per_query: 5000
  
ingester:
  chunk_target_size: 1048576      # Smaller chunks (1MB)
  chunk_idle_period: 15m          # Flush more frequently
  max_chunk_age: 1h
```

#### Issue 3: Slow Queries

**Symptom:** Queries timeout or take too long

**Check:**

```bash
# Check query performance
curl http://localhost:3100/metrics | grep loki_query_duration
```

**Solutions:**

1. **Use specific time ranges:**

```logql
# Bad
{job="api"}

# Good
{job="api"}[1h]
```

2. **Add more label filters:**

```logql
# Bad
{job="api"} |= "error"

# Good
{job="api", level="error", namespace="prod"}
```

3. **Enable query splitting:**

```yaml
query_range:
  split_queries_by_interval: 15m
  parallelise_shardable_queries: true
```

#### Issue 4: High Cardinality

**Symptom:** Too many streams, poor performance

**Check:**

```bash
# Count streams
curl http://localhost:3100/loki/api/v1/label | jq
```

**Solution:**

Don't use high-cardinality values as labels:

```yaml
# Bad - Creates too many streams
labels:
  user_id: "12345"
  request_id: "abc"

# Good - Use as filter
{job="api"} | json | user_id="12345"
```

#### Issue 5: Storage Issues

**Symptom:** "no space left on device"

**Check:**

```bash
# Check disk usage
df -h /loki
du -sh /loki/*

# Check storage metrics
curl http://localhost:3100/metrics | grep loki_ingester_memory_chunks
```

**Solution:**

1. **Enable retention:**

```yaml
compactor:
  retention_enabled: true
  compaction_interval: 5m

limits_config:
  retention_period: 168h  # 7 days
```

2. **Use object storage:**

```yaml
storage_config:
  aws:
    s3: s3://region/bucket
```

#### Issue 6: Missing Labels

**Symptom:** Logs don't have expected labels

**Check in Grafana:**

```logql
# View all labels for a stream
{job="api"}
```

**Solution in Alloy:**

```yaml
# Add labels during collection
loki.source.file "logs" {
  targets = [...]
  forward_to = [loki.relabel.add_labels.receiver]
}

loki.relabel "add_labels" {
  forward_to = [loki.write.loki.receiver]
  
  rule {
    target_label = "environment"
    replacement  = "production"
  }
}
```

#### Issue 7: Connection Errors

**Symptom:** "connection refused" or "timeout"

**Check:**

```bash
# Test network connectivity
curl http://loki:3100/ready

# Check if Loki is listening
netstat -tlnp | grep 3100

# Check firewall
iptables -L
```

**Solution:**

```yaml
# Ensure correct network config
networks:
  - loki  # Same network

# Verify service URLs
url: "http://loki:3100/loki/api/v1/push"  # Use service name in Docker
# or
url: "http://loki-gateway.loki-stack.svc.cluster.local/loki/api/v1/push"  # Kubernetes
```

### Debug Commands

```bash
# Check Loki API
curl http://localhost:3100/ready
curl http://localhost:3100/metrics
curl http://localhost:3100/config | jq

# Query Loki directly
curl -G -s "http://localhost:3100/loki/api/v1/query" \
  --data-urlencode 'query={job="api"}' \
  | jq

# Check ingestion
curl -G -s "http://localhost:3100/loki/api/v1/labels" | jq

# View ring status
curl http://localhost:3100/ring | jq
```

---

## 🎓 Conclusion

Congratulations! You've learned everything about Centralized Logging with Grafana Loki!

### What We Covered

✅ **Understanding Centralized Logging** - Why it matters and how it works
✅ **Loki Architecture** - Components and data flow
✅ **Installation** - Both VM (Docker) and Kubernetes
✅ **Configuration** - From basic to advanced setups
✅ **LogQL** - Powerful query language
✅ **Grafana** - Visualization and dashboards
✅ **Best Practices** - Production-ready guidelines
✅ **Troubleshooting** - Solving common issues

### Next Steps

1. **Start Small** - Deploy the simple Docker Compose example
2. **Experiment** - Try different LogQL queries
3. **Build Dashboards** - Create your own monitoring dashboards
4. **Scale Up** - Move to Kubernetes for production
5. **Optimize** - Fine-tune based on your needs

### Resources

- **Official Documentation:** <https://grafana.com/docs/loki/latest/>
- **GitHub:** <https://github.com/grafana/loki>
- **Community:** <https://community.grafana.com/>
- **Tutorials:** <https://grafana.com/tutorials/>

### Quick Reference Card

```bash
# Start Loki (Docker)
docker-compose up -d

# View logs
docker-compose logs -f

# Stop Loki
docker-compose down

# Install Loki (Kubernetes)
helm install loki grafana/loki -n loki-stack

# Check status
kubectl get pods -n loki-stack

# Port forward Grafana
kubectl port-forward svc/grafana 3000:80 -n loki-stack

# Uninstall
helm uninstall loki -n loki-stack
```

### Remember

- **Start simple**, then scale
- **Labels are key** - Keep them low cardinality
- **Query efficiently** - Filter early, narrow time ranges
- **Monitor Loki itself** - Use metrics and alerts
- **Practice** - The more you use it, the better you'll get!

---

## 📝 Appendix

### Glossary

| Term | Definition |
|------|------------|
| **Chunk** | Compressed block of log entries |
| **Stream** | Set of logs with same labels |
| **Label** | Key-value pair for log categorization |
| **Ingester** | Component that buffers and stores logs |
| **Querier** | Component that executes queries |
| **Distributor** | Component that receives and routes logs |
| **LogQL** | Loki's query language |
| **Cardinality** | Number of unique label combinations |

### Additional Examples

Check the `/examples` directory for more:

- Multi-tenant setup
- Advanced security configurations
- Custom dashboards
- Integration with other tools

---

**Happy Logging! 🎉**

*This guide was created with ❤️ for the DevOps community.*

*Last updated: October 2025*
-e

---

# APPENDIX A: Ready-to-Use Query Examples

# Ready-to-Use LogQL Query Examples

Copy and paste these queries directly into Grafana!

## 🔍 Basic Queries

### View All Logs from a Service

```logql
{job="api"}
```

### View Logs from Multiple Services

```logql
{job=~"api|web|database"}
```

### Filter by Namespace (Kubernetes)

```logql
{namespace="production"}
```

---

## 🔴 Error Detection

### Find All Errors

```logql
{job="api"} |= "ERROR"
```

### Case-Insensitive Error Search

```logql
{job="api"} |~ "(?i)error|exception|fail"
```

### Errors Excluding Specific Types

```logql
{job="api"} |= "ERROR" != "timeout"
```

### Count Errors Per Minute

```logql
sum(rate({job="api"} |= "ERROR" [1m]))
```

### Error Rate by Service

```logql
sum by (job) (rate({namespace="prod"} |= "ERROR" [5m]))
```

---

## 📊 JSON Log Queries

### Parse JSON Logs

```logql
{job="api"} | json
```

### Filter JSON by Field Value

```logql
{job="api"} | json | level="ERROR"
```

### Filter by HTTP Status Code

```logql
{job="api"} | json | status >= 500
```

### Complex JSON Filtering

```logql
{job="api"} 
  | json 
  | status >= 400 
  | method != "OPTIONS"
  | line_format "{{.timestamp}}: {{.method}} {{.path}} - Status {{.status}}"
```

---

## ⚡ Performance Monitoring

### Average Response Time

```logql
avg(
  avg_over_time(
    {job="api"} 
      | json 
      | unwrap response_time_ms [5m]
  )
) by (endpoint)
```

### 95th Percentile Response Time

```logql
quantile_over_time(0.95,
  {job="api"} 
    | json 
    | unwrap duration [5m]
)
```

### Slow Requests (>1 second)

```logql
{job="api"} 
  | json 
  | duration > 1000
  | line_format "Slow request: {{.endpoint}} took {{.duration}}ms"
```

### Requests Per Second by Endpoint

```logql
sum by (endpoint) (
  rate({job="api"} | json [5m])
)
```

---

## 🌐 HTTP/NGINX Monitoring

### Status Code Distribution

```logql
sum by (status) (
  count_over_time({job="nginx"} | json [5m])
)
```

### 4xx Error Rate

```logql
sum(
  rate({job="nginx"} | json | status >= 400 | status < 500 [5m])
)
```

### 5xx Error Rate

```logql
sum(
  rate({job="nginx"} | json | status >= 500 [5m])
)
```

### Top 10 Requested Paths

```logql
topk(10,
  sum by (path) (
    count_over_time({job="nginx"} | json [1h])
  )
)
```

---

## 👥 User Activity

### Find Logs for Specific User

```logql
{job="api"} | json | user_id="12345"
```

### Active Users Per Hour

```logql
count(
  count by (user_id) (
    count_over_time(
      {job="api"} 
        | json 
        | user_id != "" [1h]
    )
  )
)
```

### Top 20 Active Users

```logql
topk(20,
  sum by (user_id) (
    count_over_time({job="api"} | json | user_id != "" [24h])
  )
)
```

---

## 🔐 Security Monitoring

### Failed Login Attempts

```logql
{job="auth"} |= "login failed" | json
```

### Brute Force Detection (>10 failures/min)

```logql
sum by (ip) (
  rate({job="auth"} |= "login failed" | json [1m])
) > 10
```

### Unauthorized Access Attempts (403)

```logql
{job="api"} | json | status_code = "403"
```

### Admin Actions

```logql
{job="api"} 
  |= "admin" 
  | json 
  | action != "login"
  | line_format "Admin: {{.user}} → {{.action}} on {{.resource}}"
```

---

## 🐛 Debugging

### Find by Request ID

```logql
{job="api"} | json | request_id="abc-123-xyz"
```

### Find by Trace ID

```logql
{namespace="prod"} | json | trace_id="trace-abc-123"
```

### Follow User Session

```logql
{job="api"} 
  | json 
  | session_id="sess_789"
  | line_format "[{{.level}}] {{.timestamp}}: {{.message}}"
```

### Database Connection Errors

```logql
{job="api"} |~ "database|connection|timeout"
```

---

## 📈 Metrics & Aggregations

### Log Volume Per Service

```logql
sum by (job) (rate({namespace="prod"}[5m]))
```

### Error Percentage

```logql
(
  sum(rate({job="api"} |= "ERROR" [5m])) 
  / 
  sum(rate({job="api"}[5m]))
) * 100
```

### Top 10 Error Messages

```logql
topk(10,
  sum by (error_msg) (
    count_over_time(
      {job="api"} 
        | json 
        | error_msg != "" 
        |= "ERROR" [1h]
    )
  )
)
```

### Logs Per Pod (Kubernetes)

```logql
sum by (pod) (rate({namespace="prod"}[5m]))
```

---

## ☸️ Kubernetes Specific

### Pod Restart Events

```logql
{namespace="prod"} |= "restarting" | json
```

### OOMKilled Events

```logql
{namespace="prod"} |= "OOMKilled" | json
```

### ImagePullBackOff Errors

```logql
{namespace="prod"} |= "ImagePullBackOff" | json
```

### Logs from All Pods in Namespace

```logql
{namespace="production"}
```

### Logs from Specific Deployment

```logql
{namespace="prod", deployment="api-server"}
```

---

## 🎨 Formatted Output

### Colorful Error Display

```logql
{job="api"} 
  | json 
  | line_format "{{if eq .level \"ERROR\"}}🔴{{else if eq .level \"WARN\"}}🟡{{else}}✅{{end}} {{.message}}"
```

### Clean Timestamp Format

```logql
{job="api"} 
  | json 
  | line_format "{{.timestamp | unixEpoch | date \"2006-01-02 15:04:05\"}}: {{.message}}"
```

### Structured Output

```logql
{job="api"} 
  | json 
  | line_format "Time: {{.timestamp}} | User: {{.user_id}} | Action: {{.action}} | Status: {{.status}}"
```

---

## 📊 Dashboard Queries

### Panel 1: Total Log Volume

```logql
sum(rate({namespace="prod"}[1m]))
```

### Panel 2: Error Rate Over Time

```logql
sum by (job) (rate({namespace="prod"} |= "ERROR" [5m]))
```

### Panel 3: P95 Response Time

```logql
quantile_over_time(0.95,
  {job="api"} | json | unwrap response_time [5m]
) by (endpoint)
```

### Panel 4: Top Errors (Table)

```logql
topk(10,
  sum by (error_msg) (
    count_over_time({job="api"} |= "ERROR" | json [1h])
  )
)
```

### Panel 5: Success Rate %

```logql
100 - (
  (
    sum(rate({job="api"} |= "ERROR" [5m])) 
    / 
    sum(rate({job="api"}[5m]))
  ) * 100
)
```

---

## 🎯 Production Use Cases

### Deployment Health Check

```logql
# Check for errors after deployment
{namespace="prod", deployment="api"} 
  |= "ERROR" 
  | json 
  | __timestamp__ > now() - 5m
```

### Cost Analysis

```logql
# Find expensive endpoints
avg by (endpoint) (
  avg_over_time(
    {job="api"} 
      | json 
      | unwrap response_time_ms [1h]
  )
)
```

### Customer Impact Assessment

```logql
# Find which users are affected by errors
{job="api"} 
  |= "ERROR" 
  | json 
  | user_id != ""
  | line_format "User {{.user_id}} experienced: {{.error_msg}}"
```

---

## 💡 Pro Tips

### Combine Multiple Conditions

```logql
{job="api"} 
  |= "ERROR" 
  != "timeout" 
  |~ "database|connection"
  | json 
  | status >= 500
```

### Use Time Windows Effectively

```logql
# Last 5 minutes
{job="api"}[5m]

# Last hour
{job="api"}[1h]

# Last day
{job="api"}[24h]
```

### Label Filtering Best Practices

```logql
# ✅ Good - Specific labels first
{namespace="prod", job="api", level="error"}

# ❌ Avoid - Too broad
{job="api"} | json | namespace="prod"
```

---

## 🔄 Real-Time Monitoring

### Live Error Stream

```logql
{namespace="prod"} |= "ERROR" | json
```

### Live User Activity

```logql
{job="api"} 
  | json 
  | user_id != ""
  | line_format "{{.timestamp}}: User {{.user_id}} → {{.action}}"
```

### Live Traffic Volume

```logql
rate({job="api"}[1m])
```

---

**Remember:**

- Test queries on small time ranges first
- Use labels to narrow down quickly
- Parse only when needed
- Build complex queries step by step

For more details, see: **Loki-Complete-Guide.md**
-e

---

# APPENDIX B: Quick Reference Card

# LogQL Quick Reference Cheat Sheet

## Stream Selectors

```logql
{job="api"}                          # Exact match
{job="api", env="prod"}              # Multiple labels
{job=~"api|web"}                     # Regex match
{job!="test"}                        # Not equal
```

## Line Filters

```logql
|= "error"                           # Contains
!= "debug"                           # Not contains
|~ "error|exception"                 # Regex match
!~ "info|debug"                      # Regex not match
```

## Parsers

```logql
| json                               # Parse JSON
| logfmt                             # Parse key=value
| regexp "pattern"                   # Regex extraction
| pattern `<ip> - <time>`           # Pattern matching
```

## Label Filters

```logql
| status >= 500                      # Numeric comparison
| level = "ERROR"                    # String equality
| duration > 5s                      # Duration
```

## Formatting

```logql
| line_format "{{.field}}"          # Format output
| label_format new={{.old}}         # Rename/add labels
| unwrap field                       # Extract numbers
```

## Metric Queries

```logql
rate({job="api"}[5m])               # Rate per second
count_over_time(...[5m])            # Count logs
sum by (label) (...)                # Aggregate
quantile_over_time(0.95, ...[5m])   # 95th percentile
topk(10, ...)                       # Top 10
```

## Common Patterns

### Error Monitoring

```logql
# Error rate
sum(rate({namespace="prod"} |= "ERROR" [5m]))

# Errors by service
sum by (job) (rate({namespace="prod"} |= "ERROR" [5m]))
```

### Performance

```logql
# Average response time
avg(avg_over_time({job="api"} | json | unwrap duration [5m]))

# 95th percentile
quantile_over_time(0.95, {job="api"} | json | unwrap duration [5m])
```

### Debugging

```logql
# Find by request ID
{job="api"} | json | request_id="abc-123"

# Slow queries
{job="db"} | json | duration > 1000
```

Full documentation: See Loki-Complete-Guide.md
